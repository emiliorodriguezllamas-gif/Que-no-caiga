@echo off
title Que no caiga - MODO INTERNET GLOBAL
setlocal

echo ==========================================
echo    PREPARANDO JUEGO PARA INTERNET
echo ==========================================
echo.

echo [1/4] Limpiando sesiones previas...
powershell -Command "Stop-Process -Id (Get-NetTCPConnection -LocalPort 3000 -ErrorAction SilentlyContinue).OwningProcess -Force" 2>nul

echo [2/4] Encendiendo el motor del juego...
start /b node server.js
timeout /t 5 /nobreak > nul

echo [3/4] Obteniendo tu llave de acceso...
echo.
echo --------------------------------------------
for /f "tokens=*" %%i in ('curl -s https://ifconfig.me') do echo TU PASSWORD ES: %%i
echo --------------------------------------------
echo (Copia estos numeros para entrar al link)
echo.

echo [4/4] Creando link publico...
npx localtunnel --port 3000
