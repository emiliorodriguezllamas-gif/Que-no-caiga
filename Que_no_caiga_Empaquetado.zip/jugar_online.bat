@echo off
title Drop ^& Bounce - ONLINE MODE
setlocal

echo ==========================================
echo    INICIANDO EL JUEGO EN MODO ONLINE
echo ==========================================
echo.

REM 1. Comprobar si node_modules existe
if not exist node_modules (
    echo [INFO] No se detectaron las dependencias. Instalando...
    call npm install
    if %errorlevel% neq 0 (
        echo [ERROR] Hubo un problema instalando las dependencias.
        pause
        exit /b %errorlevel%
    )
)

REM 2. Iniciamos el servidor en segundo plano
echo [INFO] Encendiendo el servidor local...
start /b cmd /c "npm start"

REM 3. Esperamos un par de segundos para que el servidor arranque
timeout /t 3 /nobreak > nul

REM 4. Lanzamos el Tunel con Localtunnel
echo [INFO] Creando túnel de acceso desde Internet...
echo [!] COMPARTE LA URL QUE APARECERA A CONTINUACION:
echo.

npx localtunnel --port 3000

pause
