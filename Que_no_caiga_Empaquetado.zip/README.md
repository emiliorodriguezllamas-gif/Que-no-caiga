# Drop & Bounce

Un juego cooperativo global en tiempo real desarrollado como prueba de concepto para la comunidad. Construido sobre tecnologías Web (HTML5 Canvas) y un servidor Node.js/Socket.io.

## Características Principales
* **1 Bola para el Mundo:** Todos juegan con las mismas físicas.
* **Sistema de Construcción Táctil/Ratón:** Crea plataformas momentáneas de ayuda.
* **Cola de Espectador:** Si hay 10 personas jugando en pantalla, te conviertes en espectador en la cola hasta que una de ellas quede inactiva (2 minutos) o abandone.
* **Monetización lista:** Contenedores `ad-container` preparados para alojar banners de Google AdSense o similar. Botón Rewarded Ad simulado para adelantar posiciones de la cola.

## Requisitos
* [Node.js](https://nodejs.org/) instalado en el sistema (v14 o superior recomendado).

## Instalación y ejecución en local

1. Abre tu terminal (ej. PowerShell, CMD, Bash) en esta misma carpeta.
2. Descarga e instala todas las dependencias mediante NPM:
   ```bash
   npm install
   ```
3. Inicia el servidor del juego:
   ```bash
   npm start
   ```
4. Verificamos que indique el puerto `3000`. Abre tu navegador y navega a:
   [http://localhost:3000](http://localhost:3000)

## Cómo Probar el sistema de "Colas" (Queue)
Para simular estar en cola, puedes abrir varias ventanas o pestañas de "Incógnito" al juego, en cuanto entres con la ventana número 11, estarás oficialmente en modo espectador ("cola") y verás funcionar el sistema de posiciones en tiempo real. 

Pulsar en el botón "Ver anuncio para saltar la cola" te ascenderá a la cima prioritaria de esperas (con un mock de la integración API pertinente que deberías reemplazar en `client.js`).
